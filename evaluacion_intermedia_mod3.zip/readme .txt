#EVALUACION INTERMEDIA MODULO3
***
SISTEMA DE INFORMACION PARA EMPRESA DE ASESORIAS DE PREVENCION DE RIESGOS

Este sistema de informaci�n est� realizado para la mejora de gesti�n, control, seguridad y disponibilidad de informaci�n de una empresa. 
***
La soluci�n planteada cuenta con 3 tipos de Usuarios: Cliente,  Administrativo y Profesional, y tablas adicionales que se heredan de Cliente, pudiendo insertar datos en el sistema de informaci�n y realizar consultas para la obtenci�n de informaci�n espec�fica.
***
***
#INSTRUCCIONES:
***
Debe ejecutar el sistema en un entorno de navegador web. Para ello la carpeta contiene los siguientes archivos html:
***
index.html: pagina principal la que tiene enlaces a las siguientes p�ginas:
***
contacto.html: formumlario para consultas.
***
crearcapacitaciones.html: Formulario para crear una capacitaci�n en el sistema.
***
listarcapacitaciones.html: Listado de capacitaciones registradas.
***
listadousuarios.html: Listado con los usuarios existentes.
***
crearusuario.html: Este formulario permite crear un usuario en el sistema.
***
editarcliente.html: Este formulario permite modificar los datos de un usuario del tipo cliente.
                    Para acceder a esta p�gina lo debe hacer a trav�s del listado de usuarios, en el �cono �Editar usuario�,
                    siempre que este �ltimo sea de tipo cliente.
***
editaradministrativo.html: Este formulario permite modificar los datos de un usuario del tipo administrativo.
                           Para acceder a esta p�gina lo debe hacer a trav�s del listado de usuarios,
                           en el �cono �Editar usuario�, siempre que este �ltimo sea de tipo administrativo.
***
editarprofesional.html: Este formulario permite modificar los datos de un usuario del tipo profesional.
                        Para acceder a esta p�gina lo debe hacer a trav�s del listado de
                        usuarios, en el �cono �Editar usuario�, siempre que este �ltimo sea de tipo profesional.
***

#COLABORACION
El proyecto fue realizado por Mauricio Sep�lveda, Marcos Hanson, Mauricio Mar�n, Nicolas Bonilla.
***
#REPOSITORIO
https://github.com/Mauricio-Marin/evaluacion_intermedia_modulo3.git


